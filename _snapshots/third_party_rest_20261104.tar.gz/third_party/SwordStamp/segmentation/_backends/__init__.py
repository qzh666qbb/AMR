"""Lazy-loaded segmentation backends."""
