(function () {
  'use strict';
  const data = window.AMR_REVIEW_STATUS;
  if (!data || data.rows.length !== 192) return;
  let scope = 'new171';
  const $ = (id) => document.getElementById(id);
  const states = {
    ORIGINAL_GRAPH_READOUT_MATCH: '原图已一致',
    SAVED_REVISION_READOUT_MATCH: '修订后恢复',
    FROZEN_STRUCTURAL_EXCLUSION: '结构排除',
    REVIEWED_READOUT_UNRESOLVED: '仍待程序处理'
  };
  const scopes = document.querySelectorAll('[data-scope]');

  function render() {
    const metrics = data.metrics[scope];
    const batch = scope === 'new171' ? '本批 171 条' : '全部 192 条';
    const original = metrics.original_v2_primary_matches;
    const matched = metrics.saved_revision_v2_primary_matches;
    $('review-count').textContent = metrics.project_review_adopted;
    $('denominator').textContent = metrics.denominator;
    $('match-count').textContent = matched;
    $('match-detail').textContent = `原图 ${original} 条 + 修订后恢复 ${matched - original} 条`;
    $('excluded-count').textContent = metrics.structural_exclusions;
    $('pending-count').textContent = metrics.remaining_eligible_readout_cases.length;
    $('accounting').textContent = `${matched} 条读出一致 + ${metrics.structural_exclusions} 条结构排除 + ${metrics.remaining_eligible_readout_cases.length} 条待处理 = ${metrics.denominator} 条。`;
    scopes.forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.scope === scope)));
    const download = $('download');
    download.href = `./assets/COMPLETED_${metrics.denominator}.csv`;
    download.textContent = scope === 'new171' ? '下载本批清单 CSV ↓' : '下载全部清单 CSV ↓';
    const selectedState = $('state-filter').value;
    const query = $('search').value.trim().toLocaleLowerCase();
    const numericQuery = /^\d+$/.test(query);
    const rows = data.rows.filter((row) =>
      (scope === 'all192' || row.in_new171) &&
      (selectedState === 'all' || row.technical_state === selectedState) &&
      (!query || (numericQuery
        ? row.canonical_index === Number(query)
        : [row.case_id, row.category_label, row.condition_label, states[row.technical_state]]
          .some((value) => value.toLocaleLowerCase().includes(query)))));
    const body = $('case-rows');
    body.replaceChildren();
    if (!rows.length) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 5;
      td.className = 'empty-row';
      td.textContent = '没有符合筛选的案例；点击“重置筛选”查看全部已完成记录。';
      tr.appendChild(td);
      body.appendChild(tr);
    } else {
      const fragment = document.createDocumentFragment();
      rows.forEach((row) => {
        const tr = document.createElement('tr');
        tr.dataset.index = row.canonical_index;
        tr.dataset.state = row.technical_state;
        const columns = [
          [String(row.canonical_index), 'index'],
          [row.condition_label, ''],
          [row.category_label, ''],
          ['已完成并采纳', 'review-state'],
          [states[row.technical_state],
            row.technical_state === 'REVIEWED_READOUT_UNRESOLVED'
              ? 'technical-state pending-text' : 'technical-state']
        ];
        columns.forEach(([value, className]) => {
          const td = document.createElement('td');
          td.textContent = value;
          td.className = className;
          tr.appendChild(td);
        });
        fragment.appendChild(tr);
      });
      body.appendChild(fragment);
    }
    $('list-count').textContent = `${batch} · 显示 ${rows.length} / ${metrics.denominator} 条 · 全部已完成并采纳`;
  }
  scopes.forEach((button) => button.addEventListener('click', () => {
    scope = button.dataset.scope;
    render();
  }));
  $('state-filter').addEventListener('change', render);
  $('search').addEventListener('input', render);
  $('remaining-only').addEventListener('click', () => {
    $('state-filter').value = 'REVIEWED_READOUT_UNRESOLVED';
    $('search').value = '';
    render();
  });
  $('reset').addEventListener('click', () => {
    $('state-filter').value = 'all';
    $('search').value = '';
    render();
  });
  render();
}());
