window.AMR_REVIEW_STATUS = {
  "metrics": {
    "new171": {
      "denominator": 171,
      "assistant_review_completed": 171,
      "project_review_adopted": 171,
      "structural_exclusions": 19,
      "original_v2_primary_matches": 109,
      "saved_revision_v2_primary_matches": 147,
      "remaining_eligible_readout_cases": [
        54,
        55,
        77,
        151,
        183
      ],
      "technical_state_counts": {
        "ORIGINAL_GRAPH_READOUT_MATCH": 109,
        "FROZEN_STRUCTURAL_EXCLUSION": 19,
        "SAVED_REVISION_READOUT_MATCH": 38,
        "REVIEWED_READOUT_UNRESOLVED": 5
      }
    },
    "all192": {
      "denominator": 192,
      "assistant_review_completed": 192,
      "project_review_adopted": 192,
      "structural_exclusions": 20,
      "original_v2_primary_matches": 110,
      "saved_revision_v2_primary_matches": 167,
      "remaining_eligible_readout_cases": [
        54,
        55,
        77,
        151,
        183
      ],
      "technical_state_counts": {
        "ORIGINAL_GRAPH_READOUT_MATCH": 110,
        "FROZEN_STRUCTURAL_EXCLUSION": 20,
        "SAVED_REVISION_READOUT_MATCH": 57,
        "REVIEWED_READOUT_UNRESOLVED": 5
      }
    }
  },
  "rows": [
    {
      "canonical_index": 0,
      "case_id": "fd13af0e7696574df465",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 1,
      "case_id": "61a5acb1b7301fee1ce7",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 2,
      "case_id": "de09bdd7031a9815a110",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 3,
      "case_id": "51b8115f921737d1eada",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 4,
      "case_id": "5e13aa2ac122850f5402",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 5,
      "case_id": "b75b0bf104a3a5853c6f",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 6,
      "case_id": "8c89d1e10faf55faf962",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 7,
      "case_id": "4a4d48c11fd457c60d13",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 8,
      "case_id": "45f245f9a372cad012c0",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 9,
      "case_id": "fd39fb4cedf94376a94c",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 10,
      "case_id": "9ea351ee8e6fc425a66c",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 11,
      "case_id": "511a541e8648b9abd4d0",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 12,
      "case_id": "148e340c9fc253353718",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "否认对象中心词不一致",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 13,
      "case_id": "3add0d20fcfdbf2704ad",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "否认对象中心词不一致",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 14,
      "case_id": "fb91c519962923bc3b84",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 15,
      "case_id": "99d858c7d49d48a3aec1",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 16,
      "case_id": "b3c74d5f00abe5f4e05d",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 17,
      "case_id": "ac5d345c00a692d94047",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 18,
      "case_id": "5bc56a39410e86b07903",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 19,
      "case_id": "8a46a473ff3084b9ad76",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 20,
      "case_id": "209e3bd3a7ceeab6c342",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 21,
      "case_id": "e099921501142f26c1c1",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 22,
      "case_id": "0faa3d41809398b2044a",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 23,
      "case_id": "72408110de5be31b5d01",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 24,
      "case_id": "6c792b59b2a844b3570f",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 25,
      "case_id": "2c52954ee6d9df868dc9",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 26,
      "case_id": "8c6ee5e9abac1806b3a1",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 27,
      "case_id": "6e02bffb28025ecf1993",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 28,
      "case_id": "5c97be745dd912557810",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 29,
      "case_id": "44a97a58be42f33c1358",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 30,
      "case_id": "e384598876cdef90fef9",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 31,
      "case_id": "910c7b18842e73a86585",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 32,
      "case_id": "315a4972e67af39f1d77",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 33,
      "case_id": "7cd582bb40d87787e4cb",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 34,
      "case_id": "783f229c8167aab8df50",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 35,
      "case_id": "23ddab6391ba01637c5b",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 36,
      "case_id": "f959770b002dd9398b67",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "接收分句缺失",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 37,
      "case_id": "91fc2d3eb9ebfcf70465",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 38,
      "case_id": "eff1cf84fcc9f89a57ee",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 39,
      "case_id": "d0d922b6453cba746506",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 40,
      "case_id": "ff37182ef25351a9bd6b",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 41,
      "case_id": "6c18b0a727bb2db8244f",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 42,
      "case_id": "688f60dcfea8184fea0d",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 43,
      "case_id": "280438b79eddc87b25c2",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 44,
      "case_id": "21ae9669645eda717846",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 45,
      "case_id": "8788b51b09901b2f2ffc",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 46,
      "case_id": "572eb709a9805b092682",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 47,
      "case_id": "345b93ea0f17d1a0d3e5",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 48,
      "case_id": "de3d7efc5074a666d3cd",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 49,
      "case_id": "78ea66b0c2e19ba839a4",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "否认分句缺失",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 50,
      "case_id": "d3e986b7a83689cd3cfa",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "接收者姓名缺失",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 51,
      "case_id": "f38de65cfd20b0b91cbe",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 52,
      "case_id": "d6fd7b7c3c5f612a46c4",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 53,
      "case_id": "8e7225514873d32abcc3",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 54,
      "case_id": "69da037cc7ea83b59793",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "物品限定关系",
      "review_status": "已完成并采纳",
      "technical_state": "REVIEWED_READOUT_UNRESOLVED"
    },
    {
      "canonical_index": 55,
      "case_id": "224c96e537ec7bfd9de9",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "物品限定关系",
      "review_status": "已完成并采纳",
      "technical_state": "REVIEWED_READOUT_UNRESOLVED"
    },
    {
      "canonical_index": 56,
      "case_id": "64013021817edd51ff17",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 57,
      "case_id": "34e04952779e18755607",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 58,
      "case_id": "7fdc82354bfb7565c912",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "发送者姓名被代词替换",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 59,
      "case_id": "2156d0d1875e5c048536",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "发送者姓名被代词替换",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 60,
      "case_id": "79aa0ab192a95bc263e2",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 61,
      "case_id": "8ce8ab66ba482c7ff792",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 62,
      "case_id": "57d91c41ee0a649c6fff",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 63,
      "case_id": "9b88919ba1151563b226",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 64,
      "case_id": "be4a58b7b30892df5aec",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 65,
      "case_id": "cf18c8fd0a7852577538",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 66,
      "case_id": "585db0ecd02716b6c4d1",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "否认对象中心词不一致",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 67,
      "case_id": "b9fc3ed9570f107e1823",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "否认对象中心词不一致",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 68,
      "case_id": "3710d908e33927735870",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 69,
      "case_id": "190fef9084e5750363ac",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 70,
      "case_id": "1b095f4c27bebb79398e",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 71,
      "case_id": "01b4c057f4c8191203d0",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 72,
      "case_id": "9da16da05b8703042a47",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 73,
      "case_id": "2ae3714291506f111888",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 74,
      "case_id": "a2aebad96844763fc301",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 75,
      "case_id": "2a6364b04cb607d91d37",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 76,
      "case_id": "87d43913a1dc441ac5bc",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 77,
      "case_id": "b8713f515a46cd4eea4b",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "物品限定关系",
      "review_status": "已完成并采纳",
      "technical_state": "REVIEWED_READOUT_UNRESOLVED"
    },
    {
      "canonical_index": 78,
      "case_id": "8d293ffd5bd90f4cf0bf",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 79,
      "case_id": "2709f27d7efff9af5faf",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 80,
      "case_id": "097d742b980370e07d80",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 81,
      "case_id": "0860ed9dab8ff22706a0",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 82,
      "case_id": "521d0d73f4d2a7f4eab3",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 83,
      "case_id": "f8aee44a3f38716eaedb",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 84,
      "case_id": "2fe7f5300528108e4600",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 85,
      "case_id": "58760e965909ff5ae9b1",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 86,
      "case_id": "a3afef4e8f7852982ff7",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 87,
      "case_id": "2a67574995555438ca2f",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "接收者姓名缺失",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 88,
      "case_id": "30eb0d6ce2d0d2a9b438",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 89,
      "case_id": "57432c519aed3b39b9cc",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 90,
      "case_id": "bf236eb0bd72f6975e32",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 91,
      "case_id": "6085b1f04a877492cc48",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 92,
      "case_id": "1581ec1c5ddb6acc90fa",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 93,
      "case_id": "b9da0b8eee9b31d372f8",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 94,
      "case_id": "8d4a1e3d9864202e3c8f",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 95,
      "case_id": "f03a6051723e3ad60837",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 96,
      "case_id": "3532695cd88bcaccd587",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 97,
      "case_id": "bcbb7c3718b45198e9c0",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 98,
      "case_id": "d5fb8ba3cfb0cb784f09",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 99,
      "case_id": "1f2180d77ecb556b6289",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 100,
      "case_id": "ea77633f850fb6c52512",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 101,
      "case_id": "9a15cd069d880f37eea0",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 102,
      "case_id": "20c70bd009542e95ef95",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 103,
      "case_id": "bcd83b7d68d457da0453",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 104,
      "case_id": "d43d19f2b8294ceffe27",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 105,
      "case_id": "40e04a2757f4d5b5b34a",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 106,
      "case_id": "8f6bdeeea8c9f32af21f",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 107,
      "case_id": "f574632a22d117a5042e",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 108,
      "case_id": "04d0687ccfd82e0fe5cd",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 109,
      "case_id": "09a394dae1f2f9a6808a",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 110,
      "case_id": "5eef1774454721f499e2",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 111,
      "case_id": "cbab7755baed96a89da8",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 112,
      "case_id": "ac1b6406c123e654a898",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 113,
      "case_id": "23702503c9351fc70e04",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 114,
      "case_id": "b88c4b521e74c4e2807a",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 115,
      "case_id": "e27681acda38c6c05bf1",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 116,
      "case_id": "bd774deab031505197ba",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 117,
      "case_id": "e78dada89be5a77804cb",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 118,
      "case_id": "1a531e190278df1eecf2",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 119,
      "case_id": "83c792af36cb4f6016e6",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 120,
      "case_id": "ea2fc16c9e30d073a713",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 121,
      "case_id": "ef172d54794b1faaac58",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 122,
      "case_id": "a027cb1a22628ad68314",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 123,
      "case_id": "f1bca585503c5e4ec356",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 124,
      "case_id": "143895c293376970eb24",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 125,
      "case_id": "0b900fcb8d6c0ee7c890",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "发送者姓名被代词替换",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 126,
      "case_id": "dbf0b570f6bc5ca8f377",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 127,
      "case_id": "2ae63f08b83e6ca3695b",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 128,
      "case_id": "6acf1043471d29968b5d",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 129,
      "case_id": "0bd51555987967fbb622",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 130,
      "case_id": "a8b77d9179c6e1d8dd4c",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 131,
      "case_id": "b743ffa4ec59907c2ed6",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 132,
      "case_id": "dfc4078a4fee48c9ab25",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 133,
      "case_id": "00848a3314a043611803",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 134,
      "case_id": "a3d70f90c075caf545ed",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 135,
      "case_id": "445ceb4e07f91e9411c6",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 136,
      "case_id": "03b86ad632c4d8de4985",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 137,
      "case_id": "c557633c2ed3a4171f3e",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 138,
      "case_id": "a546e7c5fb79cd278816",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 139,
      "case_id": "fced1bbbfb4a382b5daa",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 140,
      "case_id": "e25e7b285b45163eb807",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 141,
      "case_id": "4c6717e29fb901fec5c3",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 142,
      "case_id": "d4e21c99f296985b93fa",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 143,
      "case_id": "3a3d12aee21ceddacd92",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 144,
      "case_id": "76781d4c15fa2dc8db13",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 145,
      "case_id": "5d3acf751b29bfcbe4ac",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 146,
      "case_id": "280840a0fc2093e883fe",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "否认对象中心词不一致",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 147,
      "case_id": "8ec53d80db161a3f92cc",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 148,
      "case_id": "886cd36a250f614efd37",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 149,
      "case_id": "b7218c733c636aac216c",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 150,
      "case_id": "79960951efd5bdf2f4ec",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 151,
      "case_id": "bd19ffea52a1e6083d7a",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "REVIEWED_READOUT_UNRESOLVED"
    },
    {
      "canonical_index": 152,
      "case_id": "d449586babe261481745",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 153,
      "case_id": "5f84ad33a23cc363dee4",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 154,
      "case_id": "cc359d0d890fc645acd4",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 155,
      "case_id": "20ee230d28d208f9fb2c",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 156,
      "case_id": "ed3640ce637b7157a299",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 157,
      "case_id": "9ae4a0097863e528d0e9",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 158,
      "case_id": "efb2b5c1f25ab56fd13b",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 159,
      "case_id": "f4f4d4c14af0302cd818",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 160,
      "case_id": "4798ae4fc9b208adef9e",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 161,
      "case_id": "3f157d2a0570d5a53a6a",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 162,
      "case_id": "157af9508288c604963f",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 163,
      "case_id": "05a914c448afec77b120",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "解析结构审计排除",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 164,
      "case_id": "b160db11d84854ae37e9",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 165,
      "case_id": "d4c704359d01fd771670",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 166,
      "case_id": "a3fc32ef4d2116ab74bb",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 167,
      "case_id": "e608b2ce6aff7e9c254e",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "发送者姓名被代词替换",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 168,
      "case_id": "0baef60127d8b267a28e",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 169,
      "case_id": "9efc40324b9a8d4435b2",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 170,
      "case_id": "0362097168db5758a45d",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 171,
      "case_id": "6beef0b4c36cf9fcaed3",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 172,
      "case_id": "60a5bd9f73f401dbb120",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 173,
      "case_id": "b74a2011242745de07bd",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "FROZEN_STRUCTURAL_EXCLUSION"
    },
    {
      "canonical_index": 174,
      "case_id": "786338880c4864e514b3",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 175,
      "case_id": "7e1c773b9755308e0458",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 176,
      "case_id": "423b036d6147db60df8e",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "让步分句作用范围",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 177,
      "case_id": "0f7f79f048ac4fc6d620",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 178,
      "case_id": "d030a7bb91df4f16ae91",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 179,
      "case_id": "40b0142d750046d0b6b4",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 180,
      "case_id": "93625e434329055b1593",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 181,
      "case_id": "7e891e94f766d427535d",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 182,
      "case_id": "025a212b14b14650b303",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 183,
      "case_id": "10bf421029a0c0a25c10",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "移动与交付表达",
      "review_status": "已完成并采纳",
      "technical_state": "REVIEWED_READOUT_UNRESOLVED"
    },
    {
      "canonical_index": 184,
      "case_id": "4f8c2eff14ac4082e0d2",
      "condition_label": "原文",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 185,
      "case_id": "c5275329ef57dd3964e5",
      "condition_label": "改写",
      "in_new171": false,
      "category_label": "接收事件来源角色",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 186,
      "case_id": "584f3cf61fdef4400edf",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 187,
      "case_id": "a009ebbdc9b0de4dca9e",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 188,
      "case_id": "375b14c7f5f9d1e01486",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 189,
      "case_id": "58494b649fe553087dc3",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    },
    {
      "canonical_index": 190,
      "case_id": "6b6741f396696c6513c5",
      "condition_label": "原文",
      "in_new171": true,
      "category_label": "代词指代尚未确定",
      "review_status": "已完成并采纳",
      "technical_state": "SAVED_REVISION_READOUT_MATCH"
    },
    {
      "canonical_index": 191,
      "case_id": "eaee3d887230c649b1a4",
      "condition_label": "改写",
      "in_new171": true,
      "category_label": "未发现目标事实错误",
      "review_status": "已完成并采纳",
      "technical_state": "ORIGINAL_GRAPH_READOUT_MATCH"
    }
  ]
};
